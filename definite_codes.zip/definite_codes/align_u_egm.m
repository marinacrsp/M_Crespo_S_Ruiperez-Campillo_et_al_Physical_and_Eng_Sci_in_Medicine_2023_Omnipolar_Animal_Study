% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that returns the average of the temporally aligned
% unipoles of the clique of 4 channels
% *************************************************************************
% 
% ALIGN_U_EGM Averages unipoles temporally aligned 
% 
%     u_egm_averaged = ALIGN_U_EGM (clique_u_egm) 
% 
%     Parameters:
%         clique_u_egm (Double): Matrix (2x2) with the unipolar channel 
%               recordings
% 
%     Returns:
%         u_egm_averaged (Double): Single unipolar signal to be considered
%               as gold standard

function u_egm_averaged = align_u_egm(clique_u_egm) 

    % Identify a unipole of reference to align the other 3 with respect to
    % the location of its global minimum
    ref_u_egm = clique_u_egm(1,:);
    [~, xref] = min(ref_u_egm);
    u_egm_averaged = ref_u_egm;
    
    for p = 2:4
        unipole = clique_u_egm(p,:);
        [~, x] = min(unipole);

        % The signal is delayed with respect to the reference uegm
        if x > xref    

            % Depending on the scale of the delay, move the signal forward 
            if (x-xref) == 1
                unipole(1) = [];
                unipole(end:end+1) = unipole(end);
            else
                unipole(1:(x-xref)) = [];
                unipole(end:end+(x - xref)) = unipole(end);
            end

        % The signal is advanced temporally with respect to the reference
        % uegm
        elseif x < xref 
            
            % Depending on the scale with which the signal is advanced with
            % respect to the reference uegm, delay the signal 
            if (xref - x) == 1
                unipole(end) = [];
                unipole = [unipole(1) unipole];

            else
                segment(1 : abs(x-xref)) = unipole(1);
                unipole = [segment unipole];
                unipole(end - abs (x-xref) + 1 : end) = [];
                clear segment

            end
        end
        
        % Compute an average with respect to the previous averaged unipole
        u_egm_averaged = (u_egm_averaged + unipole) /2; 
    end