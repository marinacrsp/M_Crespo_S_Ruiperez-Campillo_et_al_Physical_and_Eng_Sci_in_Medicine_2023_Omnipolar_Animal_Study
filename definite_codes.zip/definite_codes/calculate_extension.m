% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that prepares a vector with an extension adapted
% to the length of the structure to analyze
% *************************************************************************
%
% CALCULATE_EXTENSION Retrieves the extension of the structure containing
%                     the experiment files and prepares a vector of 
%                     positions for the post processing (plotting stage)
%
%   [p_matr, extend] = CALCULATE_EXTENSION (files)
%       
%       Parameters
%           files
%       Returns
%           p_vector (Double): vector containing positions 
%           extend (Double): the numerical value for the extension of the
%               structure

function [p_vector, extend] = calculate_extension(files)

    extend = size(files,2);
    
    for j = 1:extend
        p_vector(j) = 3*j-2;
    end
