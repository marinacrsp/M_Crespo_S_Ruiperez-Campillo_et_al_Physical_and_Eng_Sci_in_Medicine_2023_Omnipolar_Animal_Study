% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Analysis
% 
% Authors: Izan Segarra, Samuel Ruipérez-Campillo, Francisco Castells.
% Date: 07/05/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% F. Castells, S. Ruiperez-Campillo, I. Segarra, R. Cervig ́on, 
% R. Casado-Arroyo, J. Merino, J. Millet, Performance assessment 
% of electrode configurations for the estimation of omnipolar electrograms 
% from high density arrays, Computers in Biology and Medicine (2023).
%
% Description: Organize, store and plot the results from the data
% *************************************************************************
clear all;
close all;

%%% Name and define the variables
% Experiment selected set of folders
v_folder = [3, 4, 5, 6, 7, 9, 10, 11, 13];

% Interpolation number, sampling frequency, inter-electrode distances, and
% configuration method for the clique
int_n = 10;
fs = int_n * 1e3;
dist = [1 2 3 4];
c = [1 2 3 4 5];

% Obtain each signal info step by step
for j = 1:length(v_folder)
    folder_num = v_folder(j);
    [v_files] = locate_files(folder_num);

    for i = 1:length(v_files)
        clear matr_areas_alineated m_omni_normal m_omni m_widths
        file_num = v_files(i);

        [t_positions, file_name] = find_tpositions(file_num, folder_num);
        file = convertCharsToStrings(find_file_name(folder_num, file_num));
        datos = read_multielectrode(file);
        [matr_areas, m_omnipole, m_widths, m_mdev] = ...
            obtain_results_clique(datos, t_positions, int_n, dist, c, ...
                folder_num, file_num);

        signal(i).name = file_name;
        signal(i).areas = matr_areas;
        signal(i).pw = m_widths;
        signal(i).md = m_mdev;
        signal(i).ratio = m_omnipole;
    end

    file = strcat('.\metrics_results\', num2str(folder_num));
    save(file, 'signal');
    clear signal
end

%% Arrangements for organizing the information and plotting the parameters
metrics = store_metrics();
file = strcat('.\metrics_results\metrics');
save(file, 'metrics')

% Organize the information for properly plotting it
[p_matr, extend] = calculate_extension(metrics);
[b_areas, o_ratio, o_widths, o_distortion] = get_matrix(extend, metrics, p_matr);

%% Areas of bipolar loops

[t1_ratio, t2_ratio, cross_ratio] = separate_groups(o_ratio, p_matr);

figure(2)
hold on
xc = 1:4;
w = 0.18;
offset = w * 3;
boxplot(t1_ratio', 'Positions', xc - 1/3 * offset, 'Widths', w, 'Colors', 'b');
boxplot(t2_ratio', 'Positions', xc, 'Widths', w, 'Colors', 'k');
boxplot(cross_ratio', 'Positions', xc + 1/3 * offset, 'Widths', w, 'Colors', 'r');
fig = gcf;
name = 'Ratio';
sub_title = 'Ratio omnipolar axes';
xlabel('\bf Inter-electrode distance [mm]', 'FontSize', 13);
ylabel('\bf o_{x}/o_{y}', 'FontSize', 13);
define_fig_parameters_general(fig, name)

%% Pulse width

[t1_width, t2_width, cross_width] = separate_groups(o_widths, p_matr);

figure(3)
hold on
xc = 1:4;
w = 0.15;
offset = w * 3;
t1_width2 = t1_width * 1e-1;
t2_width2 = t2_width * 1e-1;
cross_width2 = cross_width * 1e-1;
boxplot(t1_width2', 'Positions', xc + 1/3 * offset, 'Widths', w, 'Colors', 'b');
boxplot(t2_width2', 'Positions', xc + 2/3 * offset, 'Widths', w, 'Colors', 'k');
boxplot(cross_width2', 'Positions', xc + offset, 'Widths', w, 'Colors', 'r');
name = 'Width';
sub_title = 'Peak omnipolar horizontal component';
xlabel('\bf Inter-electrode distance [mm]', 'FontSize', 13);
ylabel('\bf Width [ms]', 'FontSize', 13);
fig = gcf;
define_fig_parameters_general(fig, name)

%% Morphological Distortion

[t1_md, t2_md, cross_md] = separate_groups(o_distortion, p_matr);

figure(4)
hold on
xc = 1:4;
w = 0.18;
offset = w * 3;

boxplot(t1_md', 'Positions', xc - 1/3 * offset, 'Widths', w, 'Colors', 'b');
boxplot(t2_md', 'Positions', xc, 'Widths', w, 'Colors', 'k');
boxplot(cross_md', 'Positions', xc + 1/3 * offset, 'Widths', w, 'Colors', 'r');
fig = gcf;
name = 'Morphological Distortion';
sub_title = 'Maximum amplitude horizontal component';
xlabel('\bf Inter-electrode distance [mm]', 'FontSize', 13);
ylabel('\bf [mV]', 'FontSize', 13);
define_fig_parameters_general(fig, name)

