% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Analysis
% 
% Authors: Izan Segarra, Samuel Ruipérez-Campillo, Francisco Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% F. Castells, S. Ruiperez-Campillo, I. Segarra, R. Cervig ́on, 
% R. Casado-Arroyo, J. Merino, J. Millet, Performance assessment 
% of electrode configurations for the estimation of omnipolar electrograms 
% from high density arrays, Computers in Biology and Medicine (2023).
%
% Description: Function that corrects bipolar loops with open ends for
% posterior operations
% *************************************************************************
% CLOSE_BIPOLE Retrieves a bipole with the ends closed
%
%   bipole_closed = CLOSE_BIPOLE (bipole)
%       
%       Parameters
%           bipole (Double): bipolar matrix
%       Returns
%           bipole_closed (Double): closed bipolar matrix

function bipole_closed = close_bipole(bipole)
    % Get the number of leads in the bipole
    [Nleads, ~] = size(bipole);

    % Calculate the correction needed for each lead
    for i = 1:Nleads
        correction(i, :) = linspace(0, bipole(i, end) - bipole(i, 1), ...
            length(bipole));
    end

    % Apply the correction to close the bipole
    bipole_closed = bipole - correction;

    % Remove the last column from the bipole_closed
    bipole_closed(:, end) = [];
end
