% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description: function that takes the bipolar matrix as input and returns 
% the propagation angle of the wavefront
% *************************************************************************
% COMPUTE_ANG_MAX Obtains the angle formed with the horizontal axis 
%                 by the bipolar loop

%     [ang_max] = COMPUTE_ANG_MAX (b_egm)
%
%     Parameters:
%         b_egm (Double): Matrix (2x2) containing the two orthogonal 
%           bipoles bx and by
% 
%     Returns:
%         ang_max (Double): Angle (Degrees) of propagation of the wavefront
%             across the region formed by the four electrodes composing the
%             clique

function [ang_max] = compute_ang_max (bipole)
        
       % Transform from cartesian to polar coordinates
       [ang, ro] = cart2pol(bipole(1,:),bipole(2,:)); 

       % The begm loop points in the direction of wavefront propagation,
       % retrieve then the angle formed with the horizontal axis
       [~, xpost] = max(ro);
       ang_max = rad2deg(ang(xpost));


