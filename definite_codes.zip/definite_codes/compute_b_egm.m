% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that computes the bipoles from a clique according
% to a specified arrangement
% *************************************************************************
%
% COMPUTE_B_EGM Obtains the bipole for the clique with a specified 
%               configuration of electrodes (triangular 1, 2, ..., cross)
%
%     [b_egm] = COMPUTE_B_EGM (clique, conf)
%
%     Parameters:
%         clique (Double): Matrix (2 x 2) containing the 4 unipolar egm 
%             signals
%         conf (Double): Configuration selected (triangular 1, 2,... cross)
%
%     Returns:
%         b_egm (Double): Matrix containing the computed bipolar egm 
%             (2 x sample length)

function [b_egm] = compute_b_egm(clique, conf)
    switch conf
        case 1
            b_x = clique(4,:) - clique(3,:);
            b_y = clique(1,:) - clique(3,:);
            b_egm = [b_x; b_y];
        case 2
            b_x = clique(4,:) - clique(3,:);
            b_y = clique(2,:) - clique(4,:);
            b_egm = [b_x; b_y];
        case 3
            b_x = clique(2,:) - clique(1,:);
            b_y = clique(1,:) - clique(3,:);
            b_egm = [b_x; b_y];
        case 4
            b_x = clique(2,:) - clique(1,:);
            b_y = clique(2,:) - clique(4,:);
            b_egm = [b_x; b_y];
        case 5
            matr_Rot = [cosd(45) -sind(45); sind(45) cosd(45)];
            b_x = clique(2,:) - clique(3,:);
            b_y = clique(1,:) - clique(4,:);
            matr_corrected = matr_Rot * [b_x; b_y];
            b_egm = matr_corrected;
    end
end
