% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description: Function that estimates the ground truth omnipole based on
% the theoretical principle
% *************************************************************************
%
% COMPUTE_GROUND_TRUTH Provides an omnipole out of a unipolar signal to be 
%                      considered as the ground truth 
% 
% ground_truth_o_egm = COMPUTE_GROUND_TRUTH (u_egm, int_num)
% 
% Parameters:
%     u_egm (Double): Unipolar signal
%     int_num (Double): Interpolation number
% 
% Returns:
%     ground_truth_o_egm (Double): Estimated ground truth to be compared 
%        with the empirical omnipoles

function ground_truth_o_egm = compute_ground_truth (u_egm, int_num)

    ground_truth_o_egm = - gradient(u_egm) * int_num;

