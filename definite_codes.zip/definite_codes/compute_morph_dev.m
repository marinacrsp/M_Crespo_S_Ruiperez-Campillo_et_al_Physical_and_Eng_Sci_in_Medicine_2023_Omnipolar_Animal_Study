% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description: Function that assesses the morphological distortion of the
% empirical omnipole with respect to the ground truth 
% *************************************************************************
%
% COMPUTE_MORPH_DEV Computes the morphological deviation of the omnipole 
%                   with respect to the theoretically derived one, 
%                   obtained from the average of the four unipolar signals
%                   previously aligned, and differenciated
%
% [std_err] = COMPUTE_MORPH_DEV (o_egm_center, o_egm)
%
%     Parameters
%         o_egm_center (Double): Mathematically estimated omnipole, 
%           theoretically derived and averaged from the unipolar electrodes
%         o_egm (Double): Matrix containing the omnipolar vectors, the one 
%           aligned with the propagation direction and the residual
%
%     Returns
%         std_err (Double): Morphological deviation quantified by 
%            computing the standard deviation

function std_err = compute_morph_dev(o_egm_center, o_egm)
    [~, xref] = max(o_egm_center);

    o_egm = o_egm(1,:);
    [~, x] = max(o_egm);

    if x > xref    
        if x - xref == 1
            o_egm(1) = [];
            o_egm(end : end + 1) = o_egm(end);
        else
            o_egm(1 : (x - xref)) = [];
            o_egm(end : end + (x - xref)) = o_egm(end);
        end
    elseif x < xref 
        if (xref - x) == 1
            o_egm(end) = [];
            o_egm = [o_egm(1) o_egm];
        else
            segment(1 : abs(x - xref)) = o_egm(1);
            o_egm = [segment o_egm];
            o_egm (end - abs(x - xref) + 1 : end) = [];
            clear segment
        end
    end

    o_egm = normalize_signal(o_egm);
    o_egm_center = normalize_signal(o_egm_center);

    sum_err = 0;

    for i = 1:length(o_egm)
        err = (o_egm_center(i) - o_egm(i))^2;
        sum_err = sum_err + err;
    end

    std_err = sqrt(sum_err / length(o_egm));
end
