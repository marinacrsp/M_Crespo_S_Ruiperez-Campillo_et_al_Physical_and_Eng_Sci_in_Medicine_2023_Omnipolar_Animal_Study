% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description: Function that computes the omnipole of a clique
% *************************************************************************
% COMPUTE_O_EGM Computes the omnipole by orienting the bipolar loop 
%               with respect to the direction of wavefront propagation,
%               generating an orientation independent bipole
%
% [o_egm] = COMPUTE_O_EGM (ang_max, b_egm)
% 
%     Parameters
%         ang_max (Double): angle (deg) formed by the bipolar loop with 
%           respect to the horizontal axis, also referred to as the 
%           wavefront propagation angle
%         b_egm (Double): Matrix containing the orthogonal bipolar 
%           vectors bx and by
% 
%     Returns
%         o_egm (Double): Matrix containing the computed omnipolar 
%           signal, or virtual bipole whose horizontal component is aligned
%           with the wavefront propagation

function [o_egm] = compute_o_egm(ang_max, b_egm)
    ang_max = deg2rad(ang_max);

    if ang_max >= 0
        ang_max = rad2deg(ang_max);
    else
        ang_max = rad2deg(2*pi + ang_max);
    end

    matr_rot = [cosd(-ang_max) -sind(-ang_max); sind(-ang_max) cosd(-ang_max)];
    o_egm = matr_rot * [b_egm(1,:); b_egm(2, :)];
end
