% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description: Function that estimates the width of the omnipolar egm 
% *************************************************************************
%
% COMPUTE_PULSE_WIDTH Estimates the width of the omnipolar egm by
%                     considering a threshold value of 10%
%
% [width] = COMPUTE_PULSE_WIDTH (omnipole)
%
%     Parameters
%         omnipole (Double): Matrix containing the orthogonal omnipolar 
%               components, the vector aligned with the propagation 
%               direction and the residual
%
%     Returns
%         width (Double): Value of the pulse width corresponding to the 
%               peak
 
function [pulse_width] = compute_pulse_width(o_egm)
    [peak_val, lat] = max(o_egm(1,:));
    cut_value = 0.10 * peak_val;
    t = 0;
    s = 0;

    for i = 1:size(o_egm,2)
        if o_egm(1,i) < cut_value && i > lat && s == 0 
            p_end = i - 1;
            s = s + 1;
        end
    end

    p_start = 0;
    for i = p_end:-1:1
        if o_egm(1,i) < cut_value && t == 0 
            p_start = i + 1;
            t = t + 1;
        end
    end

    pulse_width = p_end - p_start;
end
