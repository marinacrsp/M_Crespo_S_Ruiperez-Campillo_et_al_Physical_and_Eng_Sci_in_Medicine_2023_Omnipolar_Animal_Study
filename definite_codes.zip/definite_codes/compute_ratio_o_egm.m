% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that computes the ratio of omnipolar components 
% *************************************************************************
%
% COMPUTE_RATIO_O_EGM Obtains ratio between omnipolar axes
%
% [ratio_o_egm] = COMPUTE_RATIO_O_EGM (o_egm)
%
%     Parameters
%         o_egm (Double): Matrix (2x...) containing the horizontal and
%         vertical components of the omnipole
%
%     Returns
%         ratio_o_egm (Double): Ratio comparison between dominant and 
%           residual omnipolar amplitudes
        
function [ratio_o_egm] = compute_ratio_o_egm (o_egm)

% Omnipolar horizontal component amplitude
[x_max, ~] = max(o_egm(1,:));
[x_min, ~] = min(o_egm(1,:));

% Omnipolar vertical component amplitude
[y_max, ~] = max(o_egm(2,:));
[y_min, ~] = min(o_egm(2,:));

% Ratio of omnipolar components
x_ampl = abs(x_max - x_min);
y_ampl = abs(y_max - y_min);

ratio_o_egm = x_ampl / y_ampl;
end