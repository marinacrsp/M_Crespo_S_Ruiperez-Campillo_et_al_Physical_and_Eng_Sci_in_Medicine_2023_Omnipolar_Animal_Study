% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that cuts the pulses from the clique of unipolar
% recordings
% *************************************************************************
% 
% CUT_UEGM Returns the unipolar pulse from a matrix of electrode recordings
% 
%     clique_uegm_cut = CUT_UEGM (clique_uegm, t_positions)
% 
%     Parameters:
%         clique_uegm (double): Matrix (2x2) containing the unipolar 
%               recordings
%         t_positions (double): Time frame for the pulse cut selection
% 
%     Returns:
%         clique_uegm_cut (double): Matrix (2x2) containing the unipolar 
%               pulses

function clique_uegm_cut = cut_uegm(clique_uegm, t_positions)
    for i = 1:size(clique_uegm, 1)
        clique_uegm_cut(i, :) = clique_uegm(i, t_positions(1):t_positions(2));
    end
end
