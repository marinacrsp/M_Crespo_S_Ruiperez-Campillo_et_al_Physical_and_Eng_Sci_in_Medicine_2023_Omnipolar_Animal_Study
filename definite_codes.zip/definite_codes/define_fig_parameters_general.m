% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that sets standardized parameters for the proper
% visualization of the figures
% *************************************************************************
%
% DEFINE_FIG_PARAMETERS_GENERAL Adjusts equally the input figure 
%                               with the adequate parameters of position, 
%                               color, legends, etc
%     [] = DEFINE_FIG_PARAMETERS_GENERAL (fig, name)
%     
%     Parameters:
%         fig (Double): Figure in question
%         name (Double): Name of the variable we are plotting


function [] = define_fig_parameters_general(fig, name)
    fig.Name = name;
    fig.Color = 'white';
    fig.Position = [360 80.333333333333329 6.616666666666666e+02 ...
        5.376666666666666e+02];
    txt_t1 = '\bf T:1&4';
    txt_t2 = '\bf T:2&3';
    txt_x = '\bf Cross';
    annotation('textbox', [0.9 0.05 0.1 0.2], ...
        'String', txt_t1, 'Color', 'b', 'EdgeColor', 'none');
    annotation('textbox', [0.9 0.025 0.1 0.2], ...
        'String', txt_t2, 'Color', 'k', 'EdgeColor', 'none');
    annotation('textbox', [0.9 0 0.1 0.2], ...
        'String', txt_x, 'Color', 'r', 'EdgeColor', 'none');
end
