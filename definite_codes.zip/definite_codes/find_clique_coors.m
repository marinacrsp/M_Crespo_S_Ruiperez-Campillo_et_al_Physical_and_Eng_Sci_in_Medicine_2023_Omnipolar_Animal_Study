% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that uses the array of distances specified to
% locate a specific clique of electrodes from the 256 array 
% *************************************************************************
% 
% FIND_CLIQUE_COORS Returns an array of positions of the unipolar channels 
%                   inter-distanced the specified distance and centered/ 
%                   located at a particular position within the catheter 
%                   (tends to occupy central positions for better results)
%
%     [clique_uegm] = FIND_CLIQUE_COORS (datos, dist, folder_num, file_num)  
%
%     Parameters: 
%         datos (double): Array with the 256 unipolar channel recordings
%         dist (double): Inter-electrode distance specified (1 to 4 mm)
%         folder_num (double): Number ID of the folder experiment
%         file_num (double): Number ID of the file contained within the 
%             folder experiment
% 
%     Returns:
%         clique_uegm (double): Matrix (2x2) containing the unipolar 
%             channel recordings

function [clique_uegm] = find_clique_coors (datos, dist, folder_num, ...
    file_num)

if folder_num == 3 || folder_num == 13

    switch dist
        case 1
            clique_uegm = [datos(:,184)'; datos(:,185)'; 
                datos(:,196)'; datos(:,197)'];
        case 2
            clique_uegm = [datos(:,173)'; datos(:,175)'; 
                datos(:,197)'; datos(:,199)'];
        case 3
            clique_uegm = [datos(:,173)'; datos(:,176)'; 
                datos(:,209)'; datos(:,212)'];
        case 4
            clique_uegm = [datos(:,173)'; datos(:,177)'; 
                datos(:,221)'; datos(:,225)'];
    end

elseif folder_num == 5 || folder_num == 6 || folder_num == 7 

    switch dist 
        case 1
            clique_uegm = [datos(:,173)'; datos(:,174)'; 
                datos(:,185)'; datos(:,186)'];
        case 2
            clique_uegm = [datos(:,173)'; datos(:,175)'; 
                datos(:,197)'; datos(:,199)'];
        case 3
            clique_uegm = [datos(:,173)'; datos(:,176)'; 
                datos(:,209)'; datos(:,212)'];
        case 4
            clique_uegm = [datos(:,173)'; datos(:,177)'; 
                datos(:,221)'; datos(:,225)'];
    end
    
elseif folder_num == 10 

    if file_num == 6 || file_num == 8
        switch dist
            case 1
                clique_uegm = [datos(:,184)'; datos(:,185)'; 
                    datos(:,196)'; datos(:,197)'];
            case 2
                clique_uegm = [datos(:,173)'; datos(:,175)'; 
                    datos(:,197)'; datos(:,199)'];
            case 3
                clique_uegm = [datos(:,173)'; datos(:,176)'; 
                    datos(:,209)'; datos(:,212)'];
            case 4
                clique_uegm = [datos(:,173)'; datos(:,177)'; 
                    datos(:,221)'; datos(:,225)'];
        end

    else

        switch dist
            case 1
                clique_uegm = [datos(:,173)'; datos(:,174)'; 
                    datos(:,185)'; datos(:,186)'];
            case 2
                clique_uegm = [datos(:,173)'; datos(:,175)'; 
                    datos(:,197)'; datos(:,199)'];
            case 3
                clique_uegm = [datos(:,173)'; datos(:,176)'; 
                    datos(:,209)'; datos(:,212)'];
            case 4
                clique_uegm = [datos(:,173)'; datos(:,177)'; 
                    datos(:,221)'; datos(:,225)'];
        end

    end
    
elseif folder_num == 11 || folder_num == 9 || folder_num == 4 ...
        || folder_num == 12

    switch dist
        case 1
            clique_uegm = [datos(:,184)'; datos(:,185)'; 
                datos(:,196)'; datos(:,197)'];         
        case 2
            clique_uegm = [datos(:,184)'; datos(:,186)'; 
                datos(:,208)'; datos(:,210)'];
        case 3
            clique_uegm = [datos(:,184)'; datos(:,187)'; 
                datos(:,220)'; datos(:,223)'];
        case 4
            clique_uegm = [datos(:,184)'; datos(:,188)'; 
                datos(:,231)'; datos(:,235)'];
    end   

end