% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that provides the name of the file that is going
% to be analyzed
% *************************************************************************
% 
% FIND_FILE_NAME Gives the complete name directory where the experiment of 
%                interest is found
% 
% [data_file] = find_file_name (name_folder, file)
% 
%     Parameters:
%       folder_num (double): Number ID of the folder experiment from which we 
%          will retrieve the files  
%       file_num (double): Number ID of the file of interest from the folder
% 
%     Returns:
%       name_file(char): Name of the file in char type

function [name_file] = find_file_name(folder_num, file_num)
    if folder_num ~= 3 && folder_num ~= 5 && folder_num ~= 10  
        if file_num < 10
            name_file = strcat('.\Guill_experiments\Guill', ...
                num2str(folder_num), '\Guill', {' '}, ...
                num2str(folder_num), '.E0', num2str(file_num));
        else
            name_file = strcat('.\Guill_experiments\Guill', ...
                num2str(folder_num), '\Guill', {' '}, ...
                num2str(folder_num), '.E', num2str(file_num));
        end
    else
        if file_num < 10
            name_file = strcat('.\Guill_experiments\Guill', ...
                num2str(folder_num), '\Guill', ...
                num2str(folder_num), '.E0', num2str(file_num));
        else
            name_file = strcat('.\Guill_experiments\Guill', ...
                num2str(folder_num), '\Guill', ...
                num2str(folder_num), '.E', num2str(file_num));
        end
    end