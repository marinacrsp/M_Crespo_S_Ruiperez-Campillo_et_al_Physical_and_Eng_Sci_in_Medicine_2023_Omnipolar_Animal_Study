% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that locates the exact pulse of interest from the 
% experimental signals for their posterior processing
% *************************************************************************
%
% FIND_TPOSITIONS Opens the matlab files containing the start and end 
%                 positions of the unipolar pulse for all the files of 
%                 interest in all the experiments used from the cardiac 
%                 signals
%
%     [t_positions, file_name] = FIND_TPOSITIONS (file_num, folder_num)
% 
%     Parameters:
%         file_num (double) : Number ID of the file 
%         folder_num (double) : Number ID of the folder experiment
% 
%     Returns
%         t_positions (double) : Array with the time frame for the unipolar pulse 
%             selection
%         file_name (char) : String with the name of the file contained within
%             the folder of interest

function [t_positions, file_name] = find_tpositions(file_num, folder_num)
    matr = strcat('.\Guill_experiments\sample_positions\Guill', ...
        num2str(folder_num), '\posts.mat');
    load(matr)
    if file_num < 10
        file_name = strcat('E0', num2str(file_num));
    else
        file_name = strcat('E', num2str(file_num));
    end

    for j = 1:size(posts, 1)
        thisfile = convertStringsToChars(posts{j, 1});
        if thisfile == file_name
            value_file = j;
        end
    end

    t_positions = [posts{value_file, 2}, posts{value_file, 3}];
