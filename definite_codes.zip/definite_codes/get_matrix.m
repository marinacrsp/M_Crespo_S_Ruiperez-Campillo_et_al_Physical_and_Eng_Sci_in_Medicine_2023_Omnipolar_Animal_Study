% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that retrieves one matrix for every parameter of
% measurement, with one row for every signal recorded (38) and one column
% for every configuration method non redundant (meaning Triangles 1&4, 2&3 
% and cross) employed (3)
% *************************************************************************
% 
% GET_MATRIX Retrieves matrixes for all the parameters of measurement 
%             employed in all the file experiments selected (n# = 38), to 
%             assess the relationships between configuration groups
% 
% 
% [b_areas, o_ratio, o_widths, o_md] = GET_MATRIX ...
%                                       (extend, metrics, p_vector)        
% 
%     Parameters
%       extend (Double): Numerical value for the size of the struct 
%           containing all the measurements
%       metrics (Double): The struct with the measurement results from 
%           the 38 signals studied 
%       p_vector (Double): Vector of positions where the input information 
%           will be introduced
% 
%     Returns
%       b_areas (Double): Matrix (38 x 3) containing the bipolar loop areas 
%       o_ratio (Double): Matrix (38 x 3) containing the ratios of the 
%           omnipolar components
%       o_widths (Double): Matrix (38 x 3) containing the pulse widths of 
%           the omnipoles
%       o_md (Double): Matrix (38 x 3) containing the morphological 
%           deviation parameter


function [b_areas, o_ratio, o_widths, o_md] = get_matrix(extend, ...
    metrics, p_vector)

    for p = 1:extend
        m_areas = metrics(p).areas;
        m_widths = metrics(p).width;
        m_md = metrics(p).md;
        m_ratio = metrics(p).ratio;
    
        % Generate one matrix for every parameter measured (areas, ratios, 
        % widths and morphological distortion) useful to compare for 
        % triangles vs cross
        for i = 1:size(m_areas,1)
            b_areas(i,p_vector(p)) = mean([m_areas(i,1) m_areas(i,4)]);
            b_areas(i,p_vector(p)+1) = mean([m_areas(i,2) m_areas(i,3)]);
            b_areas(i,p_vector(p)+2) = m_areas(i,5);
            
            o_ratio(i, p_vector(p)) = mean([m_ratio(i, 1) m_ratio(i, 4)]);
            o_ratio(i, p_vector(p)+1) = mean([m_ratio(i, 2) m_ratio(i, 3)]);
            o_ratio(i, p_vector(p)+2) = m_ratio(i, 5);
            
            o_widths(i, p_vector(p)) = mean([m_widths(i,1) m_widths(i,4)]);
            o_widths(i, p_vector(p)+1) = mean([m_widths(i,2) m_widths(i,3)]);
            o_widths(i, p_vector(p)+2) = m_widths(i,5);
            
            o_md(i, p_vector(p)) = mean([m_md(i,1) m_md(i,4)]);
            o_md(i, p_vector(p)+1) = mean([m_md(i,2) m_md(i,3)]);
            o_md(i, p_vector(p)+2) = m_md(i,5);
    
        end
    end