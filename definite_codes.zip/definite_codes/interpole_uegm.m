% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that computes the interpolation of the unipolar
% pulse
% *************************************************************************
% 
% INTERPOLE_UEGM Finds the interpolated version of the unipolar pulse when 
%                indicating the interpolation number of interest
% 
%  [clique_uegm_interpolated] = INTERPOLE_UEGM (clique_uegm, int_n)
%
%  Parameters:
%     clique_uegm (double): Matrix (2x2) containing the unipolar pulse
%     int_number (double): Interpolation number
% 
%  Returns:
%     clique_uegm_interpolated (double): Interpolated version of the (2x2)
%         matrix of unipolar pulses

function [clique_u_egm_interpolated] = interpole_uegm (clique_u_egm, int_n)
for i= 1: size(clique_u_egm,1)
    clique_u_egm_interpolated(i,:)= interp (clique_u_egm(i,:), int_n);
end

end