% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervigón, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that selects the files that will be used from the 
% directory of signals
% *************************************************************************
%
% LOCATE_FILES Returns the files from the experiment folders to be used in 
%              order to compute the corresponding metrics. 
%     [v_files] = LOCATE_FILES (folder_num)
% 
%     Parameters:
%       folder_num (double): number ID of the Guill experiment from which we 
%         want to retrieve the files 
% 
%     Returns:
%       files_num (double): array containing the files of interest from the 
%         introduced Guill experiment  

function [files_num] = locate_files (folder_num)

switch folder_num  
    case 3
        files_num = [7 11 16 22 27 32];
        
    case 4
        files_num = [49 54];
        
    case 5       
        files_num = [46 47];
        
    case 6
        files_num = [2 2 42 45 56 60];

    case 7
        files_num = [2 8];
 
    case 9
        files_num = [40 45];

    case 10
        files_num = [7 4 37 34 52 55];

    case 11
        files_num = [8 4 46 44 59 62];
         
    case 13
        files_num = [2 3 16 17 24 25];       

end

