% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/06/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that normalizes the bipolar egm according to the
% magnitude value of the begm
% *************************************************************************
%
% NORMALIZE BIPOLE Normalizes the bipolar egm according to the maximum 
% diagonal of the bipolar loop
%
% [b_egm_normalized] = NORMALIZE_BIPOLE (b_egm)
%
%     Parameters:
%         b_egm (Double): Matrix containing the two orthogonal bipoles bx
%           and by
%
%     Returns:
%         b_egm_normalized (Double): Matrix with normalized values of the 
%           bipolar loop

function b_egm_normalized = normalize_bipole (b_egm)
    
    % Maximum amplitude of the bipolar loop 
    ampl = sqrt (max (abs (b_egm(1,:)))^2 + max (abs (b_egm(2,:)))^2);

    % Normalize the begm
    b_egm_normalized = b_egm / ampl;


