% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that normalizes any kind of vector according to
% its maximum amplitude
% *************************************************************************
%
% NORMALIZE_SIGNAL 
%    [n_signal] = NORMALIZE_SIGNAL (signal)
%
%   Parameters
%       signal (Double): Vector of undefined extension that is going to be
%               normalized
%
%   Returns
%       n_signal (Double): Normalized version of the vector

function n_signal = normalize_signal (signal)

n_signal = signal / (max(signal) - min(signal));

end
