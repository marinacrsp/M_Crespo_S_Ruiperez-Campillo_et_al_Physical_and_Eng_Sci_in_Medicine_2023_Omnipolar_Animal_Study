% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that computes all metrics for a clique of 
% electrodes 
% *************************************************************************
%
% OBTAIN_RESULTS_CLIQUE Computes the quality assessment for the clique 
%                       according to the inter-electrode distance selected 
%                       and the method of reconstruction of the biomarkers 
%                       stablished
%
%     [matr_areas, matr_omnipole, matr_widths, matr_mdev] = ...
%                 OBTAIN_RESULTS_CLIQUE (datos, tposts, int_n, dist, ...
%                                 configuration_type, Folder_num, file_num)
%     
%     Parameters:
%         datos (Double): Array with the 256 unipolar channel recordings
%         tpost (Double): Time frame for the pulse cut selection
%         int_n (Double): Interpolation number 
%         dist (Double): Array containing a range of distances between
%           electrodes 
%         configuration_type (Double) : Array with all the different 
%           arrangements of cliques (triangular 1, cross, etc)
%         folder_num (Double): Number ID for the folder of the experiment 
%             of interest
%         file_num (Double): Number ID for the file contained within the 
%             folder experiment
% 
%     Returns:
%         m_areas (Double): Matrix (4x5) of the areas measured within the 
%             unipolar loops
%         m_omnipole (Double): Matrix (4x5) of the parameters computed out
%             of the oEGM
%         m_widths (Double): Matrix (4x5) of the omnipolar pulse widths 
%         m_mdev (Double): Matrix (4x5) containing the morphological 
%             deviation of the empirical omnipole with respect to the gold
%             standard
        

function [m_areas, m_omnipole, m_widths, m_mdev] = ...
    obtain_results_clique(datos, tposts, int_num, dist, ...
    configuration_type, folder_num, file_num)

    % Define the variables to be obtained
    m_areas = [];
    m_omnipole = [];
    m_widths = [];
    m_mdev = [];
    
    % Obtain for each distance (1 - 4 mm) all the assessment parameters
    % from the cliques reconstructed using the different configurations of
    % electrodes (triangular, cross)
    for j = 1:length (dist)
        
        % Interelectrode distance
        inter_distance = dist(j); 

        % Retrieve the clique from the array of 256 unipolar channels
        u_egm = find_clique_coors (datos, inter_distance, folder_num, ...
            file_num);
            
        % Process the clique of unipolar signals by cutting the exact
        % unipolar pulse and interpolating the uegms
        clique_u_egm = cut_uegm (u_egm, tposts); %cut uegm
        clique_u_egm = interpole_uegm (clique_u_egm, int_num);

        % Reconstruct those saturated unipoles 
        if folder_num == 7 || folder_num == 8 || folder_num == 9 ...
            || folder_num == 4 
                clique_u_egm = reconstruct_clique(clique_u_egm);
        end    
    
        % Estimate an imaginary unipolar channel at the center of the
        % clique of electrodes
        u_egm_center = align_u_egm (clique_u_egm); 

        % Obtain the ground truth omnipole 
        o_egm_center = compute_ground_truth (u_egm_center, int_num);

        v_areas = [];
        v_ratio = [];
        v_width = [];   
        v_mdev = [];

        % For all the clique arrangement types (triangles, cross) compute
        % the metrics
        for i = 1:length(configuration_type)
            conf = configuration_type(i); 
            
            % Compute both bipoles and omnipoles from the clique according
            % to the arrangement type (triangular, cross)
            b_egm = compute_b_egm (clique_u_egm, conf);

            % Normalize the bipole
            n_bipole = normalize_bipole(b_egm);  

            ang_max = compute_ang_max (b_egm);
            o_egm = compute_o_egm (ang_max, b_egm);    

            % Obtain the measuring parameters for the b_egms and o_egms
            % (areas of loops, omnipolar ratios, morphological deviation
            % and pulse width)
            [width] = compute_pulse_width (o_egm);
            area = compute_area_loop(n_bipole); 
            [ratio_o_egm] = compute_ratio_o_egm (o_egm); 
            [mdev]= compute_morph_dev(o_egm_center, o_egm);
    
            v_areas = [v_areas, area]; 
            v_ratio = [v_ratio, ratio_o_egm];
            v_width = [v_width width];
            v_mdev = [v_mdev, mdev];
        end

        % Store the values for each iteration
        m_areas = [m_areas; v_areas]; 
        m_omnipole = [m_omnipole; v_ratio];
        m_widths = [m_widths; v_width];
        m_mdev = [m_mdev; v_mdev];
        
    end