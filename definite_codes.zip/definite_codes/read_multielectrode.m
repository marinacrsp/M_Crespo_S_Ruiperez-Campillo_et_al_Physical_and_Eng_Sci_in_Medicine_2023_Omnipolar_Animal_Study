% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Francisco Castells, Izan Segarra, Samuel Ruipérez-Campillo.
% Date: 10/07/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that reads the data registered with the
% multielectrode catheter
% *************************************************************************
%
% READ_MULTIELECTRODE Opens and reads the data registered with the 
%                    multielectrode catheter and spreads the information 
%                    of the 256 channels recorded
%
% [data] = READ_MULTIELECTRODE (file, n_samples)
%
%     Parameters:
%         file (Double): name of the file to be read 
%         n_samples (optional)
%
%     Returns
%         data (Double):  matrix (samples x 256 channels) containing the
%           voltage values recorded by the electrodes

function data = read_multielectrode (file,n_samples)
   fid=fopen(file,'r'); 
   fseek(fid, 4608, -1);
   if nargin <2
       B = fread(fid,'int16');
   else
       B = fread(fid,n_samples*256,'int16');
   end
   data = zeros(256,length(B)/256);
   i = 1:length(B);
   data(i) = B(i);
   data = data';
   fclose(fid);
  