% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that returns a clique of 4 unipolar saturated egms 
% artificially reconstructed
% *************************************************************************
% RECONSTRUCT_CLIQUE Returns a clique of 4 unipolar saturated egms 
% artificially reconstructed
%
% [clique_reconstructed] = RECONSTRUCT_CLIQUE (clique)
%
%     Parameters:
%         clique (Double): Clique of electrode recordings with saturated 
%             unipolar egm
%     Returns: 
%         clique_reconstructed (Double): Clique of reconstructed egm 
%            signals

function [clique_reconstructed] = reconstruct_clique(clique)
    for i = 1:size(clique, 1)
        clique_reconstructed(i, :) = reconstruct_unipole(clique(i, :));
    end
end
