% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that reconstructs a saturated unipole
% *************************************************************************
%
% RECONSTRUCT_UNIPOLE Reconstructs the saturated unipolar signal and tries 
%                     to estimate the real value of the missing section
%
% [u_egm_reconstructed] = reconstruct_unipole(u_egm)
%
%     Parameters
%         u_egm (Double): Saturated unipolar signal 
%
%     Returns
%         u_egm_reconstructed (Double): Unipolar signal reconstructed

function [u_egm_reconstructed] = reconstruct_unipole(u_egm)

    % Define the domain of the unipolar egm
    s_start = 0;
    x_real = 1 : length (u_egm); 

    % Locate the region where the global minimum of the function should be
    % found (contained within point 1 and point 2)
    grad_uni = gradient (u_egm)*10;
    [~, point_1] = min (grad_uni);
    [~, point_2] = max (grad_uni(point_1:end));
    point_2 = point_2 + point_1;

    % In case we are not getting the true region of global minima, introduce 
    % another condition for the saturation time frame, 
    % (forcefully longer than 50 samples)
    while point_2 - point_1 < 50
        [~, point_3] = max (grad_uni(point_2+1:end));
        point_3 = point_3 + point_2;
        point_2 = point_3;
    end
    
    % Now identify saturation region (focusing on the area from point_1 
    % to point_2)

    % Define the gold standard and thresholds to determine the saturation
    % Provide some random values 
    epsilon = 20;
    thres = 2; 
    
    % Identify the true epsilon and threshold along the saturation region
    for i = point_1:point_2
        ampl = u_egm(i) - u_egm(i-1);

        if abs(ampl) < epsilon
            epsilon = abs(ampl);
        end
    
        if abs(ampl) > epsilon
            diff = abs(abs(ampl) - epsilon);

            if diff > thres 
                thres = diff;
            end
        end

    end
    
    % Identify the exact time frame for the saturation region
    times = 0;
    for i = point_1 : point_2
        ampl = u_egm(i) - u_egm(i-1);
    
        if abs(ampl) < epsilon + thres*0.1

            % We consider we have entered the saturation
            % region or we have found a flat region within the signal
            times = times + 1; 
            
            % If this condition is satisfied for more than 4 points, we 
            % have found the starting point of the saturation 
            if times == 4                
                s_start = i - 4*times; 
            end
    
        end
    
    end
    
    % Identify the time point of the end of the saturation
    if s_start ~= 0 

        times = 0;

        for i = s_start : point_2
    
            ampl = u_egm(i + 1) - u_egm(i);

            % Give a condition to assess whether the saturation region 
            % is over
            if abs(ampl) > epsilon + thres*0.1 
                times = times + 1; 
            end

        end

        % The saturation end is found
        s_end = i - floor(.25*times); 

        % Reconstruct the localized saturation region within the signal by
        % means of a cubic spline interpolation

        % The saturation region defined
        width_saturation = s_end - s_start; 
        
        % Prepare the required parameters to compute the interpolation
        % determining a condition that the reconstructed global minimum
        % must satisfy
        p = 2/9; 

        % Localize the middle point from the saturation region
        s_mid = floor(width_saturation/2);
        s_mid = s_mid + s_start;
        
        samples = x_real;
        samples(s_start + 1 : s_end - 1) = [];
        i1 = find(samples == s_start);
        i2 = find(samples == s_end);

        % Build the mask with the missing points to be interpolated
        x_samples = [samples(1 : i1) s_mid samples(i2 : end)];

        % Identify the domain of the mask
        u_sampled = u_egm(x_samples);

        % Give manually the value of the global minimum of the unipole,
        % computed from the equation below
        y_min = - (width_saturation/p + abs(u_egm(s_mid)));
        u_sampled(i1+1) = y_min;

        % Reconstruct the unipolar saturated signal with cubic spline
        % interpolation
        yy = interp1(x_samples, u_sampled, x_real, 'spline');
    
    else

        % In case the unipole was not saturated
        yy = u_egm;

    end
    
    u_egm_reconstructed = yy;
    
    

