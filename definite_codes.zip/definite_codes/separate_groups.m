% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/06/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that separates a matrix containing certain info
% (i.e. areas of bipolar loops, omnipolar ratios, omnipolar widths, etc)
% into three separate groups, t (1&4), t (2&3) and cross to be compared
% or plotted
% *************************************************************************
%
% SEPARATE_GROUPS Splits a matrix with information coming from the measured
%                 parameters of the 38 signals, into three different groups
%                 corresponding to the three different configurations of 
%                 clique (triangular 1 & 4, triangular 2 & 3 and the cross 
%                 arrangement)
%
%   [t1, t2, cross] = SEPARATE_GROUPS (metric_matrix, position_vector)
%
%   Parameters
%       metric_matrix (Double): Matrix with the measurements from the 38
%           signals (i.e. b_areas, o_widths, etc) (number of signals x 3)
%       position_vector (Double): Vector of positions
%
%   Returns
%       t1 (Double): Triangular arrangements 1 and 4, averaged measurements
%       t2 (Double): Triangular arrangements 2 and 3, averaged measurements
%       cross (Double): Cross configuration, averaged measurements

function [t1, t2, cross] = separate_groups(metric_matrix, position_vector)
    for u = 1:length(position_vector)
        t1(:, u) = metric_matrix(:, position_vector(u));
        t2(:, u) = metric_matrix(:, position_vector(u) + 1);
        cross(:, u) = metric_matrix(:, position_vector(u) + 2);
    end
end