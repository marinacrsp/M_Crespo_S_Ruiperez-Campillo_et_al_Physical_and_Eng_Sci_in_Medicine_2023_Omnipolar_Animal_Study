% *************************************************************************
% QCEP ITACA UPV
% Omnipolar Evaluation and Assessment 
% 
% Authors: Marina Crespo, Izan Segarra, Samuel Ruipérez-Campillo, Francisco
% Castells.
% Date: 10/08/2022
% 
% Any individual benefiting from any of this code must cite the work as: 
% S. Ruiperez-Campillo, M. Crespo, F. Castells, A.Tormos, A. Guill, 
% A. Alberola R. Cervig ́on, J. Heimer, F. J Chorro, J. Millet, F.
% Castells.
% Evaluation and Assessment of Clique Arrangements for the Estimation of 
% Omnipolar Electrograms in High Density Electrode Arrays: 
% An Experimental Animal Model Study, 
% Physical and Engineering Sciences in Medicine (2023).
%
% Description : Function that stores the data just obtained from the files
% and sorts it altogether.
% *************************************************************************
%
% STORE_METRICS Organizes the data coming from the parameters of assessment
%               and stores it into an individual matlab structure
%
%   metrics = STORE_METRICS ()
%
%     Paramenters
%         
%     Returns
%         total_metrics (): structure containing the measurements from the 
%             #n of files 

function total_metrics = store_metrics()
    % The data is already organized into MATLAB files within the folder we
    % saved them into, named after the folder number experiment they belong to
    for i = 3:13
        % There is a folder numbered from 3 - 13, except for 8 and 12.
        if i ~= 8 && i ~= 12
            file = strcat('.\metrics_trial\', num2str(i));
            load(file)

            if i == 3
                struct_size = 0;
            elseif i > 3
                struct_size = size(total_metrics, 2);
            end
            
            % Return a new structure with extension the total number of
            % files there are (38 signals)
            for u = 1:size(signal, 2)
                struct_size = struct_size + 1;
                total_metrics(struct_size).name = signal(u).name;
                total_metrics(struct_size).areas = signal(u).areas;
                total_metrics(struct_size).ratio = signal(u).ratio;
                total_metrics(struct_size).width = signal(u).pw;
                total_metrics(struct_size).md = signal(u).md;
            end
        end
    end
end
